import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import http from 'http';
import { Server } from 'socket.io';

const app=express();
const server=http.createServer(app);
const allowed=process.env.CLIENT_ORIGIN?.split(',').map(x=>x.trim())||['http://localhost:5173','http://127.0.0.1:5173'];
app.use(cors({origin:allowed,credentials:true}));
app.use(express.json({limit:'20kb'}));
const io=new Server(server,{cors:{origin:allowed,methods:['GET','POST']},pingInterval:25000,pingTimeout:20000});
const roomMembers=new Map();
const publicRooms=[
 {id:'lobby',name:'The Lobby',topic:'Meet the community'},
 {id:'gaming',name:'Gaming Lounge',topic:'Squads, queues & clips'},
 {id:'music',name:'Music Corner',topic:'Listen and unwind'},
 {id:'study',name:'Focus Room',topic:'Quiet co-working'},
 {id:'hangout',name:'Late Night',topic:'Anything goes'},
 {id:'stage',name:'Community Stage',topic:'Open mic & announcements'}
];
app.get('/api/health',(_req,res)=>res.json({ok:true,service:'OpenCall signaling server',connectedUsers:io.engine.clientsCount,rooms:publicRooms.length}));
app.get('/api/rooms',(_req,res)=>res.json(publicRooms.map(r=>({...r,members:roomMembers.get(r.id)?.size||0}))));
function getUsers(roomId){const ids=[...(roomMembers.get(roomId)||[])];return ids.map(id=>{const s=io.sockets.sockets.get(id);return s?{id,name:s.data.user?.name||'Guest',avatar:s.data.user?.avatar||'OC',status:s.data.user?.status||'Available'}:null}).filter(Boolean)}
io.on('connection',socket=>{
 socket.on('join-room',({roomId,user}={})=>{
  if(typeof roomId!=='string'||!publicRooms.some(r=>r.id===roomId))return;
  if(socket.data.roomId)leaveRoom(socket);
  socket.data.roomId=roomId;
  socket.data.user={name:String(user?.name||'Guest').slice(0,32),avatar:String(user?.avatar||'OC').slice(0,4),status:String(user?.status||'Available').slice(0,32)};
  socket.join(roomId);
  if(!roomMembers.has(roomId))roomMembers.set(roomId,new Set());
  const members=roomMembers.get(roomId);const existing=[...members];members.add(socket.id);
  socket.emit('room-users',getUsers(roomId));
  setTimeout(()=>{if(socket.connected&&socket.data.roomId===roomId)socket.emit('existing-users',existing)},120);
  socket.to(roomId).emit('user-joined',{id:socket.id,...socket.data.user});
 });
 socket.on('leave-room',()=>leaveRoom(socket));
 socket.on('signal',({to,data}={})=>{
  if(typeof to!=='string'||!data||!roomMembers.get(socket.data.roomId)?.has(to))return;
  io.to(to).emit('signal',{from:socket.id,data});
 });
 socket.on('announcement',({roomId,message,name}={})=>{
  if(typeof message!=='string'||!message.trim())return;
  const clean=message.trim().slice(0,400);
  const sender=socket.data.user?.name||String(name||'Community member').slice(0,32);
  const target=roomId==='all'?null:(roomMembers.get(roomId)?.has(socket.id)?roomId:null);
  const payload={name:sender,message:clean,roomId:target||'all',at:Date.now()};
  if(target)io.to(target).emit('announcement',payload);else io.emit('announcement',payload);
 });
 socket.on('disconnect',()=>leaveRoom(socket));
});
function leaveRoom(socket){const roomId=socket.data.roomId;if(!roomId)return;socket.leave(roomId);roomMembers.get(roomId)?.delete(socket.id);if(roomMembers.get(roomId)?.size===0)roomMembers.delete(roomId);socket.to(roomId).emit('user-left',socket.id);socket.data.roomId=null}
const port=Number(process.env.PORT)||3001;
server.listen(port,'0.0.0.0',()=>console.log(`OpenCall signaling server listening on :${port}`));
