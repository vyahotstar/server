# OpenCall — Full-stack voice community

A dark, Discord-inspired React interface with an Express + Socket.IO signaling server and browser WebRTC peer-to-peer audio.

## Features
- Responsive dashboard, profile, friends, and voice-room navigation
- Six selectable voice rooms with room membership and presence events
- WebRTC audio with microphone mute/unmute, echo cancellation, noise suppression, and automatic gain control
- Camera and screen-share capture controls
- Community-wide announcements or announcements to the current room
- Editable display name, status, and bio persisted in browser local storage
- Server health endpoint and room listing API

## Requirements
- Node.js 18.18+ (Node 20 LTS recommended)
- A modern browser with microphone permissions

## Run locally
From this folder:

```bash
npm run install:all
npm run dev
```

Open the Vite URL printed by the client (usually http://localhost:5173). The signaling server runs on http://localhost:3001.

## Production build
```bash
npm run install:all
npm run build
npm start
```

For deployment, deploy `client` as a static site and `server` as a Node service. Set `VITE_SERVER_URL` in the client build to your public signaling-server URL. Set `CLIENT_ORIGIN` on the server to the exact deployed client origin (comma-separated for multiple origins). HTTPS is required for microphone, camera, and screen capture outside localhost. Configure a TURN server in `client/src/main.jsx` for dependable connections across restrictive NATs/firewalls; the included public STUN servers are for basic connectivity only.

## Important implementation notes
- This is a working starter, not a hardened production service. It uses mesh WebRTC, which is best for small rooms; for larger rooms use an SFU such as LiveKit, mediasoup, or Janus.
- Screen-share video tracks are attached to existing peer connections. Production-grade renegotiation and replacement-track handling should be added for robust share/camera switching across every browser.
- The broadcast feature sends an announcement event to the room (or all connected clients) and briefly boosts the local microphone gain. Browser gain boost is not a substitute for a server-side PA/priority-audio system, and can clip/distort if the microphone input is already loud. Keep announcements respectful; the server currently allows connected users to broadcast.
- Room membership and friends are in-memory/demo data; user profile is stored locally in the browser. Add authentication, database persistence, rate limits, moderation permissions, and TURN credentials before public launch.
